// Copyright Twitch Interactive, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: MIT

#pragma once

namespace Twitch::IPC::Transport {
struct Pipe;
struct TCP;
} // namespace Twitch::IPC::Transport
